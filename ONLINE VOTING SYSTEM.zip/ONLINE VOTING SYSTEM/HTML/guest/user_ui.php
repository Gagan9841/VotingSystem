

<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hmpg</title>
    <link rel="stylesheet" href="../../css/hmpg.css">
    <link rel="stylesheet" href="../../css/candidate.css">
    <script src="../../js/jquery.js"></script>

</head>

<body>
    <!-- <img class="background" src="../../img/bg.jpg" alt="background image"> -->
    <div class="header-sec">
    <div class="center-heading">
                <span class="election">Online Voting</span>
                <span class="day">System</span>
            </div>
        <div class="right-header">
        <li> <a href="../admin/admin_login.php">Admin</a></li>
        </div>
        <div class="navigation">
            <div class="logo">
                <a href="../HTML/hmpg.html"><img src="../../img/logow.png" alt="logo"></a>
            </div>
        
            <nav class="nav-content">
                <ul>
                    <li> <a href="hmpg.php"> Home</a></li>
                    <li><a href="lgn.php?viewresult=true">Result</a></li>
                    <li><a href="cnditate.php">Candidates</a></li>
                    <li><a href="lgn.php?vote=true">Vote Now</a></li>
                </ul>
                <div class="nav-right-content">
                    <ul>
                        <li><a href="lgn.php">Login</a></li>
                        <li> <a href="rgstr.php">Register</a></li>
                    </ul>
                </div>
            </nav>
            
              
        </div>
    </div>
    
    
</body>

</html>
